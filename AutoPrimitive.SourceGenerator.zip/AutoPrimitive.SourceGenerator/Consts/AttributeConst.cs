﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Consts
{
    internal sealed class AttributeConst
    {
        public const string PocoEnum = "AutoPrimitiveAttribute";

        #region attributeText

        public const string Text_PocoEnum = $@"using System;
/// <summary>
/// 枚举标记:自动创建枚举项的
/// </summary>
[AttributeUsage(AttributeTargets.Field)]
public class AutoPrimitiveAttribute : Attribute
{{
    /// <summary>
    /// 构造函数
    /// </summary>
    /// <param name=""apiUrlPost"">保存的文件名</param>
    public AutoPrimitiveAttribute(string fileName)
    {{
        this.FileName = fileName;
    }}

    /// <summary>
    /// 文件名
    /// </summary>
    public string FileName {{ get; private set; }}
}}";

        #endregion
    }
}