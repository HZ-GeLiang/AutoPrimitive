﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Consts
{
    internal sealed class GlobalConst
    {
        //public const string Namespace = "PocoGenerator";

        public const string space1 = " ";
        public const string space4 = "    ";
    }
}