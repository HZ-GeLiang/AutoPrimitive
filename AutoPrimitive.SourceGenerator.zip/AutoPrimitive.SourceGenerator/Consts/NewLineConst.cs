﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Consts
{
    internal sealed class NewLineConst
    {
        public const string csfileNewLine = WindowsNewLine;

        public const string WindowsNewLine = "\r\n";
        public const string LinuxNewLine = "\n";
        public const string MacOsNewLine = "\r";
    }
}