﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AutoPrimitive.ExtensionMethod
{
    internal static partial class StringExtensions
    {
        internal class NewLineConst
        {
            public const string WindowsNewLine = "\r\n";

            public const string LinuxNewLine = "\n";

            public const string MacOsNewLine = "\r";
        }

        public static bool EndiWithEmptyLine(this string value)
        {
            if (value == null)
            {
                return false;
            }

            var result = value.EndsWith(NewLineConst.WindowsNewLine) ||
                 value.EndsWith(NewLineConst.LinuxNewLine) ||
                 value.EndsWith(NewLineConst.MacOsNewLine);
            return result;
        }

        /// <summary>
        /// 移除String对象的最前面几个指定字符
        /// </summary>
        /// <param name="value"></param>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public static string RemovePrefix(this string value, string prefix)
        {
            if (value is null)
                return null;
            if (prefix is null || prefix.Length <= 0)
                return value;
            return value.StartsWith(prefix) ? value.Substring(prefix.Length, value.Length - prefix.Length) : value;
        }

        /// <summary>
        /// 移除String对象的最后面几个指定字符
        /// </summary>
        /// <param name="value"></param>
        /// <param name="suffix"></param>
        /// <returns></returns>
        public static string RemoveSuffix(this string value, string suffix)
        {
            if (value is null)
                return null;
            if (suffix is null || suffix.Length <= 0)
                return value;
            return value.EndsWith(suffix) ? value.Substring(0, value.Length - suffix.Length) : value;
        }
    }
}