﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.ExtensionMethod
{
    internal static partial class EnumerableExtensions
    {
        public static HashSet<TSource> ToHashSet<TSource>(this IEnumerable<TSource> source)
        {
            HashSet<TSource> hashSet = new();
            if (source == null)
            {
                return hashSet;
            }

            foreach (TSource sourceItem in source)
            {
                hashSet.Add(sourceItem);
            }
            return hashSet;
        }

        public static Dictionary<TKey, TElement> ToDictionarySameKeyContinue<TSource, TKey, TElement>(
           this IEnumerable<TSource> source,
           Func<TSource, TKey> keySelector,
           Func<TSource, TElement> elementSelector,
           IEqualityComparer<TKey> comparer)
           where TKey : notnull
        {
            if (source is null)
                throw new ArgumentNullException(nameof(source));
            if (keySelector is null)
                throw new ArgumentNullException(nameof(keySelector));
            if (elementSelector is null)
                throw new ArgumentNullException(nameof(elementSelector));
            int capacity = 0;
            if (source is ICollection<TSource> sources)
            {
                capacity = sources.Count;
                if (capacity == 0)
                    return new Dictionary<TKey, TElement>(comparer);
            }
            Dictionary<TKey, TElement> dictionary = new(capacity, comparer);
            foreach (TSource source1 in source)
            {
                var key = keySelector(source1);
                if (!dictionary.ContainsKey(key))
                {
                    dictionary.Add(key, elementSelector(source1));
                }
            }
            return dictionary;
        }
    }
}