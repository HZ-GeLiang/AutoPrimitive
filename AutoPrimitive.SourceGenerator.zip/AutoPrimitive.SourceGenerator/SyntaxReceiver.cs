﻿using AutoPrimitive.Consts;
using AutoPrimitive.SyntaxResult;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace AutoPrimitive
{
    /// <summary>
    /// 语法接收器，将在每次生成代码时被按需创建
    /// Created on demand before each generation pass
    /// </summary>
    internal class SyntaxReceiver : ISyntaxContextReceiver
    {
        public string SolutionPath { get; set; } = null;

        public List<Field_PocoColumn> Field_PocoColumnList { get; } = new();
        public List<Field_PocoEnum> Field_PocoEnumList { get; } = new();
        public List<Field_PocoOmit> Field_PocoOmitList { get; } = new();
        public List<Field_PocoTable> Field_PocoTableList { get; } = new();
        public Dictionary<GeneratorSyntaxContext, CsFile> csFile_AllList { get; } = new();
        public List<Class_PocoApi> Class_PocoApiList { get; } = new();

        public List<Class_PocoSave> Class_PocoSaveList { get; } = new();

        //以class为统计信息, 获得 class 所在的文件的的最后修改日期
        public List<Class_PocoGenerator> Class_PocoGeneratorList { get; } = new();

        /// <summary>
        /// 字面量
        /// </summary>
        public List<LiteralExpressionSyntax> LiteralExpressions { get; } = new();

        //public Dictionary<string, SyntaxNode> hashSet = new();
        /// <summary>
        /// 编译中在访问每个语法节点时被调用，我们可以检查节点并保存任何对生成有用的信息
        /// Called for every syntax node in the compilation,
        /// we can inspect the nodes and save any information useful for generation
        /// </summary>
        public void OnVisitSyntaxNode(GeneratorSyntaxContext context)
        {
            //注: 通过 SourceGenerator 创建的类 是不会加入到这里的

            //var classVisitor = new ClassVirtualizationVisitor();
            //classVisitor.Visit(context.SemanticModel.SyntaxTree.GetRoot());
            //foreach (var node in classVisitor.Classes)
            //{
            //    hashSet[node.Identifier.ValueText] = node;
            //}

            CsFile csFile;
            var csFile_AllList_Contains = csFile_AllList.ContainsKey(context);

            if (csFile_AllList_Contains)
            {
                csFile = csFile_AllList[context];
            }
            else
            {
                csFile = new CsFile()
                {
                    context = context,
                };
                csFile_AllList.Add(context, csFile);
            }

            #region GetSolutionPath

            if (SolutionPath == null) //只找一次, 原理. 找.csproj文件
            {
                //Debugger.Launch();

                //不知道用哪个
                var filePath = context.SemanticModel.SyntaxTree.FilePath;
                //var filePath = context.Node.GetLocation().SourceTree.FilePath;

                var dir = Path.GetDirectoryName(filePath);
                while (dir != null)
                {
                    var di = new DirectoryInfo(dir);
                    if (di.GetFiles("*.csproj").Length > 0)
                    {
                        break;
                    }
                    dir = di.Parent.FullName;//去上级目录
                }
                if (dir == null)
                {
                    SolutionPath = "";
                }
                else
                {
                    SolutionPath = dir;
                }
            }

            #endregion
            if (context.Node is ClassDeclarationSyntax classDeclarationSyntax)
            {
                csFile.IsClass = true;

                GetClasses(context, classDeclarationSyntax);
            }
            else if (context.Node is EnumDeclarationSyntax enumDeclarationSyntax)
            {
                csFile.IsEnum = true;
                //Debugger.Launch();
            }
            else if (context.Node is LiteralExpressionSyntax literalExpressionSyntax)
            {
                LiteralExpressions.Add(literalExpressionSyntax);
            }
        }

        /// <summary>
        /// 一个类会进来一次:  partial class会进来多次, 一个.cs文件有多个类也会进来多次
        /// </summary>
        /// <param name="context"></param>
        /// <param name="classDeclarationSyntax"></param>
        private void GetClasses(GeneratorSyntaxContext context, ClassDeclarationSyntax classDeclarationSyntax)
        {
            //var code = context.Node.SyntaxTree.ToString();

            INamedTypeSymbol namedTypeSymbol = context.SemanticModel.GetDeclaredSymbol(classDeclarationSyntax) as INamedTypeSymbol;

            if (classDeclarationSyntax.AttributeLists.Count <= 0)
            {
                return;
            }
        }
    }
}