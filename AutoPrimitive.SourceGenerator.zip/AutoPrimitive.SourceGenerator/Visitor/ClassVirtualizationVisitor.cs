﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Visitor
{
    //https://stackoverflow.com/questions/31143056/roslyn-how-to-get-all-classes
    internal class ClassVirtualizationVisitor : CSharpSyntaxRewriter
    {
        public List<ClassDeclarationSyntax> Classes { get; set; } = new List<ClassDeclarationSyntax>();

        public override SyntaxNode VisitClassDeclaration(ClassDeclarationSyntax node)
        {
            node = (ClassDeclarationSyntax)base.VisitClassDeclaration(node);
            Classes.Add(node); // save your visited classes

            //string className = node.Identifier.ValueText;
            //Classes.Add(className); // save your visited classes

            return node;
        }
    }
}