﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace AutoPrimitive.Handle
{
    internal class PocoGeneratorHandler
    {
        /// <summary>
        /// 处理 PocoGenerator Attribute
        /// </summary>
        /// <param name="dict_attr_PocoGenerator"></param>
        /// <param name="func_FileCreate"></param>
        /// <exception cref="Exception"></exception>
        internal static void HandleAttr_PocoGenerator(Dictionary<string, object> dict_attr_PocoGenerator, out Func<string, bool> func_FileCreate)
        {
            //文件生成之前的委托操作
            /*
              createWhen 的值 来自 enum PocoGenerateWhen
              FileNotExists = 1, 文件不存在时新增
              Always = 2 一直创建,会覆盖以存在的文件
            */
            /*    Func<string, bool>*/
            func_FileCreate = null;
            if (Convert.ToInt32(dict_attr_PocoGenerator["createWhen"]) == 1)
            {
                func_FileCreate = (filePath) => File.Exists(filePath);
                return;
            }
            if (Convert.ToInt32(dict_attr_PocoGenerator["createWhen"]) == 2)
            {
                //覆盖/创建文件,这里什么代码都不用写
                return;
            }
            throw new Exception("不支持的枚举值(PocoGenerateWhen),可能是程序没修改到位");
        }
    }
}