﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Handle
{
    internal class PocoEnumHandler
    {
        /// <summary>
        /// 处理 PocoEnum Attribute
        /// </summary>
        /// <param name="dict_Attr_PocoEnum"></param>
        /// <param name="type"></param>
        /// <param name="saveFileName"></param>
        internal void HandleAttr_PocoEnum(Dictionary<string, object> dict_Attr_PocoEnum, out int type, out string saveFileName)
        {
            type = -1;
            saveFileName = "";
            if (dict_Attr_PocoEnum.ContainsKey("type"))
            {
                type = (int)dict_Attr_PocoEnum["type"];
            }
            if (dict_Attr_PocoEnum.ContainsKey("saveFileName"))
            {
                saveFileName = (string)dict_Attr_PocoEnum["saveFileName"];
            }
        }
    }
}