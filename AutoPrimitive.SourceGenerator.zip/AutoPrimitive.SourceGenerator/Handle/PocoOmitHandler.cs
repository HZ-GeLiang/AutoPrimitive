﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using AutoPrimitive.Consts;
using AutoPrimitive.ExtensionMethod;
using AutoPrimitive.Parser.ParserObject;
using AutoPrimitive.SyntaxResult;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace AutoPrimitive.Handle
{
    internal class PocoOmitHandler
    {
        public const string Err_未找到类 = "在编译时未在程序集中找对应的类";
        public const string Err_缺少配置文件信息 = "未配置";
        public const string Err_未配置父类 = "未配置要继承的父类";

        public static void GetDto_cscode(Field_PocoOmit field_PocoOmit, Dictionary<string, CsharpClass> dict,
            string saveFileName, out string csCode, out bool isException)
        {
            csCode = "";
            isException = false;
            #region 获得cscode

            HashSet<string> Exclude_HashSet = field_PocoOmit.Json_PocoOmit.Exclude.ToHashSet();

            var baseFullName = field_PocoOmit.Json_PocoOmit.BaseFullName;

            if (!dict.ContainsKey(baseFullName))
            {
                isException = true;
                csCode = $"{Err_未找到类}:{baseFullName}";
                return;
            }
            CsharpClass baseClass = dict[baseFullName];

            StringBuilder sb_dto = new StringBuilder();
            sb_dto.Append($"//This file is auto-generated. Date: {DateTime.Now:yyyy-MM-dd HH:mm:ss}").Append(NewLineConst.csfileNewLine);
            //拼接 using
            var usingTxt = baseClass.UsingTxt();
            sb_dto.Append(usingTxt);
            if (!usingTxt.EndiWithEmptyLine())
            {
                sb_dto.Append(NewLineConst.csfileNewLine);
            }

            #region 这个判断不会生效

            //因为在 Json_PocoOmit 中写了 { get; set; } = new Json_PocoOmit_FileContent();

            //Debugger.Launch();
            //var have_config_FileContent = field_PocoOmit.Json_PocoOmit.FileContent != null;
            //if (!have_config_FileContent)
            //{
            //    isException = true;
            //    csCode = $"{Err_缺少配置文件信息}FileContent";
            //    return;
            //}
            #endregion

            //拼接 namespace
            var dto_ns = field_PocoOmit.Json_PocoOmit.FileContent.Namespace;//baseClass.Namespace
            var have_ns = !string.IsNullOrEmpty(dto_ns);
            var space_class = "";

            if (have_ns)
            {
                space_class = GlobalConst.space4;
                sb_dto.Append($@"
namespace {dto_ns}
{{
");
            }

            //拼接 class

            sb_dto.Append($@"
{space_class}public partial class {saveFileName.Replace(".cs", "")}
{space_class}{{
");
            #region 拼接 property

            #region base 的父类的 property

            var base_baseFullName = "";
            foreach (BaseListSyntax @base in baseClass.baseListSyntax)
            {
                #region 获得 父类的 Fullname

                base_baseFullName = "";
                var baes_ns = "";
                var baes_name = "";

                foreach (var item in @base.Types)
                {
                    if (item is SimpleBaseTypeSyntax SimpleBaseTypeSyntax)
                    {
                        if (SimpleBaseTypeSyntax.Type is IdentifierNameSyntax IdentifierNameSyntax)
                        {
                            var allNodes = IdentifierNameSyntax.SyntaxTree.GetCompilationUnitRoot().DescendantNodes();

                            //var allNodes_txt = allNodes.Select(a => a.ToString()).ToList();
                            //baes_ns = allNodes.OfType<NamespaceDeclarationSyntax>().SingleOrDefault()?.Name.ToString();

                            //降低报错的可能性
                            baes_ns = allNodes.OfType<NamespaceDeclarationSyntax>().FirstOrDefault().Name.ToString();
                            baes_name = IdentifierNameSyntax.Identifier.ValueText;
                        }
                    }
                }

                if (string.IsNullOrEmpty(baes_name))
                {
                    isException = true;
                    csCode = $"{Err_未配置父类}";
                    return;
                }
                base_baseFullName = baes_ns != null && baes_ns.Any()
                  ? baes_ns + "." + baes_name
                  : baes_name;

                if (!dict.ContainsKey(base_baseFullName))
                {
                    isException = true;
                    csCode = $"{Err_未找到类}:{base_baseFullName}";
                    return;
                }

                #endregion

                sb_dto.Append($@"{space_class}{GlobalConst.space4}#region ").Append(base_baseFullName).Append(NewLineConst.csfileNewLine);

                foreach (CsharpClassProperty class_property in dict[base_baseFullName].Properties)
                {
                    sb_dto.Append(AppendPropertyToDto(Exclude_HashSet, class_property, space_class));
                }

                sb_dto.Append($@"{space_class}{GlobalConst.space4}#endregion ").Append(NewLineConst.csfileNewLine).Append(NewLineConst.csfileNewLine);
            }

            #endregion

            #region base 的 property

            sb_dto.Append($@"{space_class}{GlobalConst.space4}#region ").Append(baseFullName).Append(NewLineConst.csfileNewLine);

            foreach (CsharpClassProperty class_property in dict[baseFullName].Properties)
            {
                sb_dto.Append(AppendPropertyToDto(Exclude_HashSet, class_property, space_class));
            }

            sb_dto.Append($@"{space_class}{GlobalConst.space4}#endregion ").Append(NewLineConst.csfileNewLine);
            #endregion

            #endregion

            // class's }
            sb_dto.Append($@"
{space_class}}}");

            //Namespace's }
            if (have_ns)
            {
                sb_dto.Append($@"
}}");
            }
            csCode = sb_dto.ToString();
            #endregion
        }

        public static StringBuilder AppendPropertyToDto(HashSet<string> Exclude_HashSet,
            CsharpClassProperty class_property, string space_class)
        {
            StringBuilder sb_prop = new StringBuilder();
            if (Exclude_HashSet.Contains(class_property.Name) ||
                class_property.IsPrivatemodifier() ||
                class_property.AccessorList == null && class_property.ArrowExpressionClauseSyntax == null)
            {
                return sb_prop;
            }

            //属性的特性
            foreach (var txt in class_property.AttributeTxt())
            {
                sb_prop.Append($@"{space_class}{GlobalConst.space4}{txt}").Append(NewLineConst.csfileNewLine);
            }

            //属性的Summary
            foreach (string lineTxt in class_property.SummaryLines())
            {
                sb_prop.Append($@"{space_class}{GlobalConst.space4}{lineTxt}");
                if (!lineTxt.EndiWithEmptyLine())
                {
                    sb_prop.Append(NewLineConst.csfileNewLine);
                }
            }

            //属性
            sb_prop.Append($"{space_class}{GlobalConst.space4}{class_property.GetModifierString()}{GlobalConst.space1}{class_property.TypeString}{GlobalConst.space1}{class_property.Name}{GlobalConst.space1}");
            if (class_property.AccessorList != null)
            {
                sb_prop.Append($"{class_property.AccessorList}");
            }
            if (class_property.ArrowExpressionClauseSyntax != null)
            {
                sb_prop.Append($"{class_property.ArrowExpressionClauseSyntax};");
            }
            sb_prop.Append(NewLineConst.csfileNewLine);
            return sb_prop;
        }
    }
}