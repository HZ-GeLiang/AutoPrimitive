﻿using Microsoft.CodeAnalysis;
using System;
using System.Collections.Generic;
using System.Text;
using AutoPrimitive.SyntaxResult;
using AutoPrimitive.Parser;

namespace AutoPrimitive.Handle
{
    /// <summary>
    /// 要生成文件的一些配置项
    /// </summary>
    internal class FileGenerated
    {
        #region PocoApi

        public Class_PocoApi class_PocoApi { get; set; }
        public List<AttributeData> attributeDataList_PocoApi { get; set; }
        public string ApiUrlPost { get; set; }
        public INamedTypeSymbol pocoApi_namedTypeSymbol { get; set; }
        #endregion

        #region PocoGenerator

        public Class_PocoGenerator class_PocoGenerator { get; set; }

        /// <summary>
        /// 创建文件时的处理, 返回值表示: 程序是否还需要在处理 文件的创建
        /// </summary>
        public Func<string, bool> func_FileCreate { get; set; }

        /// <summary>
        /// 解析 PocoGenerator, 获得func_FileCreate
        /// </summary>
        /// <param name="fileGenerated"></param>
        /// <param name="class_PocoGenerator_attributeData"></param>
        public static void set_func_FileCreate(FileGenerated fileGenerated, AttributeData class_PocoGenerator_attributeData)
        {
            //解析 PocoGenerator, 获得func_FileCreate
            Dictionary<string, object> dict_attr_PocoGenerator =
                AttributeDataParserHelper.GetAttributeParamNameAndValue(class_PocoGenerator_attributeData);
            //设置值
            PocoGeneratorHandler.HandleAttr_PocoGenerator(dict_attr_PocoGenerator, out var func_FileCreate);
            fileGenerated.func_FileCreate = func_FileCreate;
        }

        #endregion

        #region PocoSave

        public Class_PocoSave class_PocoSave { get; set; }

        /// <summary>
        /// 保存的文件路径:默认保存到项目的根目录
        /// </summary>
        public string savePath { get; set; } = string.Empty;

        /// <summary>
        /// 自动创建文件目录
        /// </summary>
        public bool autoCreateDirectory { get; set; } = false;

        /// <summary>
        /// 解析 PocoSave, 获得 savePath + autoCreateDirectory
        /// </summary>
        /// <param name="fileGenerated"></param>
        /// <param name="class_PocoSave_attributeData"></param>
        public static void set_savePath_and_autoCreateDirectory(FileGenerated fileGenerated, AttributeData class_PocoSave_attributeData)
        {
            var dict_PocoSave = AttributeDataParserHelper.GetAttributeParamNameAndValue(class_PocoSave_attributeData);
            PocoSaveHandler.HandleAttr_PocoSave(dict_PocoSave, out var savePath, out var autoCreateDirectory);
            fileGenerated.savePath = savePath;
            fileGenerated.autoCreateDirectory = autoCreateDirectory;
        }

        #endregion

        #region todo:加入 connection

        /// <summary>
        /// 连接字符串
        /// </summary>
        public string connection { get; set; }

        #endregion
    }
}