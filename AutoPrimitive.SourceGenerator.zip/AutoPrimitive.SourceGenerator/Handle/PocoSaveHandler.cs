﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Handle
{
    internal class PocoSaveHandler
    {
        /// <summary>
        /// 处理 PocoSave Attribute
        /// </summary>
        /// <param name="dict_PocoSave"></param>
        /// <param name="savePath">保存的路径</param>
        /// <param name="autoCreateDirectory">自动创建目录</param>
        internal static void HandleAttr_PocoSave(Dictionary<string, object> dict_PocoSave, out string savePath, out bool autoCreateDirectory)
        {
            savePath = string.Empty; //默认保存到项目的根目录
            autoCreateDirectory = false; //自动创建文件目录

            if (dict_PocoSave.ContainsKey("path"))
            {
                savePath = (string)dict_PocoSave["path"];
            }

            if (dict_PocoSave.ContainsKey("createDirectory"))
            {
                autoCreateDirectory = Convert.ToBoolean(dict_PocoSave["createDirectory"]);
            }
        }
    }
}