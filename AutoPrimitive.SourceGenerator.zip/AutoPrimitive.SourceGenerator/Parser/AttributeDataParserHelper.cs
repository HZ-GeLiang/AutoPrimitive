﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using Microsoft.CodeAnalysis;

namespace AutoPrimitive.Parser
{
    internal class AttributeDataParserHelper
    {  /// <summary>
       ///
       /// </summary>
       /// <param name="attributeData"></param>
       /// <returns>返回值的Dictionary的value需要自己类型转换,这里只能返回object</returns>
       /// <exception cref="Exception"></exception>
        internal static Dictionary<string, object> GetAttributeParamNameAndValue(AttributeData attributeData)
        {
            //https://stackoverflow.com/questions/49129099/get-attribute-arguments-with-roslyn

            ImmutableArray<IParameterSymbol> constructorParams = attributeData.AttributeConstructor.Parameters;

            // Start with an indexed list of names for mandatory args
            string[] argumentNames = constructorParams.Select(x => x.Name).ToArray();

            IEnumerable<KeyValuePair<string, TypedConstant>> allArguments = attributeData.ConstructorArguments
        // For unnamed args, we get the name from the array we just made
        .Select((info, index) => new KeyValuePair<string, TypedConstant>(argumentNames[index], info))
        // Then we use name + value from the named values
        .Union(attributeData.NamedArguments.Select(x => new KeyValuePair<string, TypedConstant>(x.Key, x.Value)))
        .Distinct();

            Dictionary<string, object> paramNameAndValue = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in allArguments)
            {
                if (item.Value is TypedConstant typedConstant) //常量
                {
                    paramNameAndValue.Add(item.Key, typedConstant.Value);
                }
                else
                {
                    throw new Exception("完善方法代码" + nameof(GetAttributeParamNameAndValue));
                }
            }
            return paramNameAndValue;

            #region 获得一个参数的写法(参考)

            /*
            AttributeArgumentListSyntax argumentList =
                  ((AttributeSyntax)attributeData.ApplicationSyntaxReference.GetSyntax()).ArgumentList;
            if (argumentList != null && argumentList.Arguments != null && argumentList.Arguments.Count == 1)
            {
                string argumentVaule;
                var argument = argumentList.Arguments.First();
                if (argument.Expression is LiteralExpressionSyntax literalExpressionSyntax) //字符串字面量
                {
                    argumentVaule = literalExpressionSyntax.ToString();
                }
                else if (argument.Expression is MemberAccessExpressionSyntax memberAccessExpressionSyntax) //常量
                {
                    //if code ==   [PocoSQLServerConnection(ConnectionConst.User)]
                    //then write   memberAccessExpressionSyntax.Name.Identifier.ValueText
                    //output       User
                    var semanticModel = context.Compilation.GetSemanticModel(argument.SyntaxTree);

                    var literal = semanticModel.GetConstantValue(memberAccessExpressionSyntax);
                    if (literal.HasValue)
                    {
                        argumentVaule = literal.Value ;// as string;
                    }
                    else
                    {
                        argumentVaule = (string)null;
                    }
                }
                else
                {
                   // throw new Exception("完善代码");
                   continue;// 跳过当前表生成的操作
                }
            }
            */
            #endregion
        }
    }
}