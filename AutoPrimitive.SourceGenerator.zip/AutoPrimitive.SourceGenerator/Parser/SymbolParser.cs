﻿using AutoPrimitive.SyntaxResult;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Parser
{
    internal class SymbolParser
    {
        #region GetSymbol

        public static ISymbol GetSymbol(SemanticModel semanticModel, SyntaxNode node)
        {
            ISymbol symbol = semanticModel.GetDeclaredSymbol(node);
            return symbol;
        }

        public static ISymbol GetSymbol(CsFile csFile, SyntaxNode node)
        {
            ISymbol symbol = GetSymbol(csFile.context.SemanticModel, node);
            return symbol;
        }

        #endregion

        #region GetSymbolParent

        public static ISymbol GetSymbolParent(SemanticModel semanticModel, SyntaxNode node)
        {
            ISymbol symbol = semanticModel.GetDeclaredSymbol(node.Parent);
            return symbol;
        }

        public static ISymbol GetSymbolParent(CsFile csFile, SyntaxNode node)
        {
            ISymbol symbol = GetSymbolParent(csFile.context.SemanticModel, node);
            return symbol;
        }

        #endregion

        #region GetSymbolOriginalDefinition

        public static ISymbol GetSymbolOriginalDefinition(SemanticModel semanticModel, SyntaxNode node)
        {
            ISymbol symbol = GetSymbol(semanticModel, node).OriginalDefinition;
            return symbol;
        }

        public static ISymbol GetSymbolOriginalDefinition(CsFile csFile, SyntaxNode node)
        {
            ISymbol symbol = GetSymbolOriginalDefinition(csFile.context.SemanticModel, node);
            return symbol;
        }

        #endregion

        #region GetSymbolParentOriginalDefinition

        public static ISymbol GetSymbolParentOriginalDefinition(SemanticModel semanticModel, SyntaxNode node)
        {
            ISymbol symbol = GetSymbolParent(semanticModel, node).OriginalDefinition;
            return symbol;
        }

        public static ISymbol GetSymbolParentOriginalDefinition(CsFile csFile, SyntaxNode node)
        {
            ISymbol symbol = GetSymbolParentOriginalDefinition(csFile.context.SemanticModel, node);
            return symbol;
        }

        #endregion
    }
}