﻿using AutoPrimitive.Consts;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Parser.ParserObject
{
    internal class CsharpClassProperty
    {
        // 可以解析出 : <summary> + <attribute> + <修饰符> <属性类型> <属性名>, 但是没有{get;set;}
        public PropertyDeclarationSyntax propertyDeclarationSyntax { get; set; }

        //                     可以解析出下面这部分
        // internal int com5   { get; set; }
        public AccessorListSyntax AccessorList { get; set; }

        //                     可以解析出下面这部分
        //internal int com7    => 1;
        public ArrowExpressionClauseSyntax ArrowExpressionClauseSyntax { get; set; }

        /// <summary>
        /// summary 标签+程序员描述的那部分
        /// </summary>
        /// <returns></returns>
        public string Summary()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var Trivia in propertyDeclarationSyntax.GetLeadingTrivia())
            {
                //SingleLineDocumentationCommentTrivia  是 整个summary
                //SingleLineCommentTrivia   是 summary 里填写的内容

                /*
    解析:
      /// <summary>
    1)---|2)-----------|3)---
    1):WhitespaceTrivia
    2):SingleLineCommentTrivia
    3):EndOfLineTrivia

                */

                if (Trivia.IsKind(SyntaxKind.WhitespaceTrivia))
                {
                    sb.Append(Trivia.ToString());
                }
                else if (Trivia.IsKind(SyntaxKind.SingleLineCommentTrivia))
                {
                    sb.Append(Trivia.ToString());
                }
                else if (Trivia.IsKind(SyntaxKind.EndOfLineTrivia))
                {
                    sb.Append(NewLineConst.csfileNewLine);
                }
            }

            var summary = sb.ToString();
            return summary;
        }

        /// <summary>
        /// 和  Summary() 不同 的是会Trim(), 每次遇到 EndOfLineTrivia 会认为是新行
        /// </summary>
        /// <returns></returns>
        public List<string> SummaryLines()
        {
            List<string> list = new List<string>();
            StringBuilder sb = new StringBuilder();
            foreach (var Trivia in propertyDeclarationSyntax.GetLeadingTrivia())
            {
                if (Trivia.IsKind(SyntaxKind.WhitespaceTrivia))
                {
                    sb.Append(Trivia.ToString().Trim());
                }
                else if (Trivia.IsKind(SyntaxKind.SingleLineCommentTrivia))
                {
                    sb.Append(Trivia.ToString().Trim());
                }
                else if (Trivia.IsKind(SyntaxKind.EndOfLineTrivia))
                {
                    if (sb.Length != 0) //sb.Length == 0 表示,sb的没有任何字符. 那么不需要添加这行
                    {
                        sb.Append(NewLineConst.csfileNewLine);
                        list.Add(sb.ToString());
                        sb.Clear();
                    }
                }
            }

            return list;
        }

        /// <summary>
        /// 主要的信息: 就是程序员描述的那部分
        /// </summary>
        /// <returns></returns>
        public string SummaryLeading()
        {
            StringBuilder sb = new StringBuilder();
            var addTriviaIndex = -1;
            var index = -1;
            foreach (var trivia in propertyDeclarationSyntax.GetLeadingTrivia())
            {
                index++;

                if (trivia.IsKind(SyntaxKind.SingleLineCommentTrivia))
                {
                    var txt = trivia.ToString();

                    if (
                        txt.StartsWith("///") && txt.Contains("<summary") ||
                        txt.StartsWith("///") && txt.Contains("</summary")
                        )
                    {
                        continue;
                    }
                    if (txt.StartsWith("///"))
                    {
                        txt = txt.Substring("///".Length, txt.Length - 3);
                    }
                    if (txt.StartsWith(" "))
                    {
                        txt = txt.TrimStart();
                    }
                    addTriviaIndex = index;
                    sb.Append(txt);
                }
                else if (trivia.IsKind(SyntaxKind.EndOfLineTrivia))
                {
                    if (index - 1 == addTriviaIndex)
                    {
                        sb.Append(NewLineConst.csfileNewLine);
                    }
                }
            }

            var summary = sb.ToString();
            return summary;
        }

        public List<string> AttributeTxt()
        {
            List<string> result = new List<string>();
            foreach (AttributeListSyntax item in propertyDeclarationSyntax.AttributeLists)
            {
                foreach (AttributeSyntax attr in item.Attributes)
                {
                    result.Add($@"[{attr}]");
                }
            }
            return result;
        }

        /// <summary>
        /// 获得 修饰符(modifier)
        /// </summary>
        /// <returns></returns>
        public List<string> GetModifiers()
        {
            List<string> list = new List<string>();
            foreach (var item in propertyDeclarationSyntax.Modifiers)
            {
                list.Add(item.ValueText);
            }

            return list;
        }

        public string GetModifierString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in propertyDeclarationSyntax.Modifiers)
            {
                stringBuilder.Append(item.ValueText).Append(" ");
            }
            var Modifiers = stringBuilder.ToString();
            return Modifiers;
        }

        /// <summary>
        /// is private 修饰符(modifier)
        /// </summary>
        /// <returns></returns>
        public bool IsPrivatemodifier()
        {
            foreach (SyntaxToken item in propertyDeclarationSyntax.Modifiers)
            {
                if (string.CompareOrdinal("private", item.ValueText) == 0)
                {
                    return true;
                }
            }
            return false;
        }

        public TypeSyntax Type => propertyDeclarationSyntax.Type;
        public string TypeString => Type.ToString();
        public string Name => propertyDeclarationSyntax.Identifier.ValueText;
    }
}