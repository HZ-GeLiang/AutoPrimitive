﻿using AutoPrimitive.Consts;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoPrimitive.Parser.ParserObject
{
    /*
     * CsharpClass 的说明:
     * 1. foreach (var node in allNodes) 的里面的代码需要完善
     * 2.  对于partial 类: 多个　partial　类就对应多个 CsharpClass,
     * 2.1 不同partial 类之间需要需要通过 context 的 Node 才能区分,
     * 2.2 不同partial 类对应多个 CsharpClass 的 属性、命名空间等Syntax 应该都是相同的(没有全部测试过，只验证了部分)

    注: 如果代码需要完善, 需要使用一个cs文件: 里面有多个类 + partial 类 来测试.
     */

    /// <summary>
    ///
    /// </summary>
    internal class CsharpClass
    {
        public GeneratorSyntaxContext context { get; set; }
        public SyntaxTree tree { get; set; }
        public string FileContent => context.Node.SyntaxTree.ToString();

        public NamespaceDeclarationSyntax namespaceDeclarationSyntax { get; set; }
        public ClassDeclarationSyntax classDeclarationSyntax { get; set; }
        public List<MethodDeclarationSyntax> methodDeclarationSyntax { get; set; } = new();
        public List<FieldDeclarationSyntax> fieldDeclarationSyntax { get; set; } = new();
        public List<ConstructorDeclarationSyntax> constructorDeclarationSyntax { get; set; } = new();
        public List<EnumDeclarationSyntax> enumDeclarationSyntax { get; set; } = new();
        public List<EnumMemberDeclarationSyntax> enumMemberDeclarationSyntax { get; set; } = new();
        public List<VariableDeclarationSyntax> variableDeclarationSyntax { get; set; } = new();
        public List<VariableDeclaratorSyntax> variableDeclaratorSyntax { get; set; } = new();
        public List<EqualsValueClauseSyntax> equalsValueClauseSyntax { get; set; } = new();
        public List<LiteralExpressionSyntax> iteralExpressionSyntax { get; set; } = new();
        public HashSet<UsingDirectiveSyntax> usingDirectiveSyntax { get; set; } = new();
        public HashSet<BaseListSyntax> baseListSyntax { get; set; } = new();

        public string UsingTxt()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in usingDirectiveSyntax)
            {
                sb.Append(item.ToString()).Append(NewLineConst.csfileNewLine);
            }
            var txt = sb.ToString();
            return txt;
        }

        /// <summary>
        /// 有些 class 没有写 命名空间时, 这里就会为null
        /// </summary>
        public string Namespace => namespaceDeclarationSyntax?.Name?.ToString();

        //public string AttributeTxt()
        //{
        //    return attributeListSyntax.ToString();
        //}

        public string Name => classDeclarationSyntax.Identifier.ValueText;
        public BaseListSyntax BaseList => classDeclarationSyntax?.BaseList;

        public IEnumerable<string> BaseListStr => this?.BaseList?.Types.Select(x => x.Type.ToString());

        public List<CsharpClassProperty> Properties { get; set; } = new();
    }
}