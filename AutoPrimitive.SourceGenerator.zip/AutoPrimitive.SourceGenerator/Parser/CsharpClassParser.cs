﻿using AutoPrimitive.Helpers;
using AutoPrimitive.Parser.ParserObject;
using AutoPrimitive.SyntaxResult;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace AutoPrimitive.Parser
{
    internal static class CsharpClassParser
    {
        //public static CsharpClass Parse(string content)
        //{
        //    var csharpClass = new CsharpClass();
        //    SyntaxTree tree = CSharpSyntaxTree.ParseText(content);
        //    csharpClass.tree = tree;
        //    //Set_csharpClass_Value(csharpClass, /*todo:...*/);
        //    return csharpClass;
        //}

        public static CsharpClass ParseClass(CsFile csFile)
        {
            if (!csFile.IsClass)
            {
                return null;
            }

            var csharpClass = new CsharpClass
            {
                context = csFile.context,
                tree = csFile.classDeclarationSyntax.SyntaxTree
            };
            /*等价(应该是的不,因为没测试出来过)
             *
            var  tree_1 = csFile.context.SemanticModel.SyntaxTree;
            var  tree_2 = csFile.context.Node.SyntaxTree
            if (tree_1 != tree_2)
            {
                Debugger.Launch();
            }
            */

            Set_csharpClass_Value(csharpClass, csFile);

            return csharpClass;
        }

        private static void Set_csharpClass_Value(CsharpClass csharpClass, CsFile csFile)
        {
            //SemanticModel SemanticModel = csFile.context.SemanticModel;

            //var allNodes = csharpClass.context.Node.SyntaxTree.GetCompilationUnitRoot().DescendantNodes(); //和下面是等价的
            CompilationUnitSyntax root = csharpClass.tree.GetCompilationUnitRoot();

            //var allTrivia = root.DescendantTrivia();
            //var allTrivia2 = allTrivia.Any(trivia => trivia.IsKind(SyntaxKind.IfDirectiveTrivia));
            //var allTrivia_txt = allTrivia.Select(a => a.ToString()).ToList();

            // DescendantNodesAndSelf()的count  比  DescendantNodes()的count 大1 ,这个1就是自己
            IEnumerable<SyntaxNode> allNodes = root.DescendantNodes();

            //members: 当前cs文件的内容: 即 一个cs文件里只有一个类, 和 一个cs文件里有多个类
            //IEnumerable<MemberDeclarationSyntax> members = allNodes.OfType<MemberDeclarationSyntax>();

            INamedTypeSymbol namedTypeSymbol = csFile.namedTypeSymbol;
            //var classAttrs = namedTypeSymbol.GetAttributes().ToList();
            //var text = csharpClass.FileContent;

            //var allNodes_list = allNodes.ToList();
            //var allNodes_txt = allNodes.Select(a => a.ToString()).ToList();
            //var index = -1;

            foreach (SyntaxNode node in allNodes)
            {
                //index++; //调试时,查看循环的次数
                if (node is BaseListSyntax baseListSyntax)
                {
                    //int a = 3;
                    // Debugger.Launch();
                    csharpClass.baseListSyntax.Add(baseListSyntax);
                }
                else if (node is UsingDirectiveSyntax usingDirectiveSyntax)
                {
                    // UsingDirectiveSyntax 不判断 symbol 了 (不知道怎么判断)
                    csharpClass.usingDirectiveSyntax.Add(usingDirectiveSyntax);
                }
                else if (node is PropertyDeclarationSyntax propertyDeclarationSyntax)
                {
                    // UsingDirectiveSyntax 判断了 symbol 了
                    var isSameParent = SymbolHelper.CompareSymbol(namedTypeSymbol, SymbolParser.GetSymbolParent(csFile, node));
                    if (isSameParent)
                    {
                        csharpClass.Properties.Add(new CsharpClassProperty
                        {
                            propertyDeclarationSyntax = propertyDeclarationSyntax
                        });
                    }
                }
                else if (node is AccessorListSyntax accessorListSyntax)
                {
                    // property 后面的 {get;set;} 部分

                    // 当前类的
                    var isSame =
                    SymbolHelper.CompareSymbol(namedTypeSymbol, SymbolParser.GetSymbol(csFile, node.Parent.Parent));
                    //当前类的上个属性
                    var lastProperty = csharpClass.Properties.LastOrDefault(); //当一个cs文件有多个类时, 假设第二个类 没有任何属性, 那么此时onLast()就会报错.
                    if (lastProperty != null)
                    {
                        var symbol1 = SymbolParser.GetSymbol(csFile, lastProperty.propertyDeclarationSyntax);
                        var symbol2 = SymbolParser.GetSymbol(csFile, node.Parent);
                        var isSameLastProperty = SymbolHelper.CompareSymbol(symbol1, symbol2);
                        if (isSame && isSameLastProperty)
                        {
                            csharpClass.Properties.Last().AccessorList = accessorListSyntax;
                        }
                    }
                }
                else if (node is ArrowExpressionClauseSyntax ArrowExpressionClauseSyntax)
                {
                    //  ArrowExpressionClauseSyntax 为 ' internal int com7 => 1' 的 => 1
                    var isSame =
                        SymbolHelper.CompareSymbol(namedTypeSymbol, SymbolParser.GetSymbol(csFile, node.Parent.Parent));
                    //当前类的上个属性
                    var lastProperty = csharpClass.Properties.LastOrDefault(); //当一个cs文件有多个类时, 假设第二个类 没有任何属性, 那么此时onLast()就会报错.
                    if (lastProperty != null)
                    {
                        var symbol1 = SymbolParser.GetSymbol(csFile, lastProperty.propertyDeclarationSyntax);
                        var symbol2 = SymbolParser.GetSymbol(csFile, node.Parent);
                        var isSameLastProperty = SymbolHelper.CompareSymbol(symbol1, symbol2!);

                        if (isSame && isSameLastProperty)
                        {
                            csharpClass.Properties.Last().ArrowExpressionClauseSyntax = ArrowExpressionClauseSyntax;
                        }
                    }
                }
                else if (node is NamespaceDeclarationSyntax namespaceDeclarationSyntax)
                {
                    csharpClass.namespaceDeclarationSyntax = namespaceDeclarationSyntax;
                }
                else if (node is ClassDeclarationSyntax classDeclarationSyntax)
                {
                    var symbol = csFile.context.SemanticModel.GetDeclaredSymbol(node);
                    var isSame = SymbolEqualityComparer.Default.Equals(namedTypeSymbol, symbol);
                    if (isSame)
                    {
                        csharpClass.classDeclarationSyntax = classDeclarationSyntax;
                    }
                }
                else if (node is MethodDeclarationSyntax methodDeclarationSyntax)
                {
                    var isSameParent = SymbolHelper.CompareSymbol(namedTypeSymbol, SymbolParser.GetSymbolParent(csFile, node));
                    if (isSameParent)
                    {
                        csharpClass.methodDeclarationSyntax.Add(methodDeclarationSyntax);
                    }
                }
                else if (node is FieldDeclarationSyntax fieldDeclarationSyntax)
                {
                    var symbolParent = csFile.context.SemanticModel.GetDeclaredSymbol(node.Parent);
                    var isSameParent = SymbolEqualityComparer.Default.Equals(namedTypeSymbol, symbolParent);
                    if (isSameParent)
                    {
                        csharpClass.fieldDeclarationSyntax.Add(fieldDeclarationSyntax);
                    }
                }
                else if (node is ConstructorDeclarationSyntax constructorDeclarationSyntax)
                {
                    var symbolParent = csFile.context.SemanticModel.GetDeclaredSymbol(node.Parent);
                    var isSameParent = SymbolEqualityComparer.Default.Equals(namedTypeSymbol, symbolParent);
                    if (isSameParent)
                    {
                        csharpClass.constructorDeclarationSyntax.Add(constructorDeclarationSyntax);
                    }
                }
                else if (node is EnumDeclarationSyntax enumDeclarationSyntax)
                {
                    csharpClass.enumDeclarationSyntax.Add(enumDeclarationSyntax);
                }
                else if (node is EnumMemberDeclarationSyntax enumMemberDeclarationSyntax)
                {
                    csharpClass.enumMemberDeclarationSyntax.Add(enumMemberDeclarationSyntax);
                }
                else if (node is VariableDeclarationSyntax variableDeclarationSyntax)
                {
                    var symbolParent = csFile.context.SemanticModel.GetDeclaredSymbol(node.Parent);
                    var isSameParent = SymbolEqualityComparer.Default.Equals(namedTypeSymbol, symbolParent);
                    if (isSameParent)
                    {
                        csharpClass.variableDeclarationSyntax.Add(variableDeclarationSyntax);
                    }
                }
                else if (node is VariableDeclaratorSyntax variableDeclaratorSyntax)
                {
                    var symbolParent = csFile.context.SemanticModel.GetDeclaredSymbol(node.Parent);
                    var isSameParent = SymbolEqualityComparer.Default.Equals(namedTypeSymbol, symbolParent);
                    if (isSameParent)
                    {
                        csharpClass.variableDeclaratorSyntax.Add(variableDeclaratorSyntax);
                    }
                }
                else if (node is EqualsValueClauseSyntax equalsValueClauseSyntax)
                {
                    csharpClass.equalsValueClauseSyntax.Add(equalsValueClauseSyntax);
                }
                else if (node is LiteralExpressionSyntax iteralExpressionSyntax)
                {
                    csharpClass.iteralExpressionSyntax.Add(iteralExpressionSyntax);
                }
                else
                {
                    //Debugger.Launch();//可以用来完善if的代码
                }
            }
        }
    }
}