﻿using AutoPrimitive.Consts;
using Microsoft.CodeAnalysis;

namespace AutoPrimitive
{
    /// <summary>
    ///
    /// </summary>
    [Generator]
    public class PocoGenerator : ISourceGenerator
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="context"></param>
        public void Initialize(GeneratorInitializationContext context)
        {
            //Debugger.Launch();//对编译时的生成器进行调试，

            //Register the attribute source
            context.RegisterForPostInitialization((i) =>
            {
            });

            // Register a syntax receiver that will be created for each generation pass
            context.RegisterForSyntaxNotifications(() => new SyntaxReceiver());
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="context"></param>
        public void Execute(GeneratorExecutionContext context)
        {
            // retrieve the populated receiver
            if (context.SyntaxContextReceiver is not SyntaxReceiver receiver)
            {
                return;
            }
            //Debugger.Launch();
        }
    }
}