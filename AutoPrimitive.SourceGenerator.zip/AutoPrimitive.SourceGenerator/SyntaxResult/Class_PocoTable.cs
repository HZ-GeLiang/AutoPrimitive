﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.CodeAnalysis;

namespace AutoPrimitive.SyntaxResult
{
    internal class Class_PocoTable
    {
        public AttributeData AttributeData { get; set; }
        public List<INamedTypeSymbol> NamedTypeSymbol { get; set; } = new();
    }
}