﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace AutoPrimitive.SyntaxResult
{
    internal class Field_PocoOmit
    {
        /// <summary>
        /// 字段
        /// </summary>
        public IFieldSymbol FieldSymbol { get; set; }

        /// <summary>
        /// 字段标记的Attribute
        /// </summary>
        public AttributeData AttributeData { get; set; }

        /// <summary>
        /// 字段的 FieldDeclarationSyntax 信息
        /// </summary>
        public FieldDeclarationSyntax FieldDeclarationSyntax { get; set; }

        public GeneratorSyntaxContext Context { get; set; }
        public VariableDeclaratorSyntax variable { get; set; }

        /// <summary>
        /// (stirng类型)字段的值
        /// </summary>
        public string FieldConstantValue { get; set; }

        /// <summary>
        /// json 对应的类模型
        /// </summary>
        public Json_PocoOmit Json_PocoOmit { get; set; }

        /// <summary>
        /// josn字符串转Json_PocoOmit 的失败的信息
        /// </summary>
        public Exception JsonConvertException { get; set; }
    }

    internal class Json_PocoOmit
    {
        /// <summary>
        /// 父类全名
        /// </summary>
        public string BaseFullName { get; set; }

        /// <summary>
        /// 排除的属性
        /// </summary>
        public string[] Exclude { get; set; }

        public Json_PocoOmit_FileContent FileContent { get; set; } = new Json_PocoOmit_FileContent();
    }

    /// <summary>
    /// 文件内容
    /// </summary>
    public class Json_PocoOmit_FileContent
    {
        /// <summary>
        /// 命名空间
        /// </summary>
        public string Namespace { get; set; } = "";
    }
}