﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace AutoPrimitive.SyntaxResult
{
    internal class Field_PocoTable
    {
        /// <summary>
        /// 字段
        /// </summary>
        public IFieldSymbol FieldSymbol { get; set; }

        /// <summary>
        /// 字段标记的的Attribute
        /// </summary>
        public AttributeData AttributeData { get; set; }

        /// <summary>
        /// 字段的 FieldDeclarationSyntax 信息
        /// </summary>
        public FieldDeclarationSyntax FieldDeclarationSyntax { get; set; }

        /// <summary>
        /// (stirng类型)字段的值
        /// </summary>
        public string FieldConstantValue { get; set; }
    }
}