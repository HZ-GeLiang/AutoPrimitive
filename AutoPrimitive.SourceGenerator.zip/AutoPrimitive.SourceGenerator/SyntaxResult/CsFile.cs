﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace AutoPrimitive.SyntaxResult
{
    internal class CsFile
    {
        public GeneratorSyntaxContext context { get; set; }

        /// <summary>
        /// context.Node is ClassDeclarationSyntax
        /// </summary>
        public bool IsClass { get; set; }

        /// <summary>
        /// context.Node is EnumDeclarationSyntax
        /// </summary>
        public bool IsEnum { get; set; }

        public INamedTypeSymbol namedTypeSymbol =>
            IsClass
            ? context.SemanticModel.GetDeclaredSymbol(classDeclarationSyntax) as INamedTypeSymbol
            : null;

        public ClassDeclarationSyntax classDeclarationSyntax =>
            context.Node as ClassDeclarationSyntax;

        //public AttributeData  AttributeData { get; set; }
        //public INamedTypeSymbol NamedTypeSymbol { get; set; }
    }
}