﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.CodeAnalysis;

namespace AutoPrimitive.SyntaxResult
{
    internal class Class_PocoApi
    {
        public AttributeData AttributeData { get; set; }
        public INamedTypeSymbol NamedTypeSymbol { get; set; }
    }
}