﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace AutoPrimitive.Helpers
{
    //https://www.thinbug.com/q/33090499
    //https://www.sapehin.com/blog/csharp-via-roslynapi-the-big-picture/

    internal class RoslynHelper
    {
        #region string类型的 Field的值

        public static string GetConstantValue(GeneratorSyntaxContext context, IFieldSymbol fieldSymbol, VariableDeclaratorSyntax variable)
        {
            /*
               * 有2种形式: 内插值字符串, 字符串字面量
               * 内插值字符串:$""  $@"" 这2种
               * 字符串字面量:""   @"" 这2种
              */

            ITypeSymbol fieldType = fieldSymbol.Type;
            var isStringFeild = fieldType.ToString() == "string";

            if (!isStringFeild)
            {
                return null;
            }
            string constantValue = null;
            //List<SyntaxNode> nodes = variable.DescendantNodes().ToList();
            foreach (var node in variable.DescendantNodes())
            {
                //          字符串字面量                 内插值字符串
                if (node is LiteralExpressionSyntax or InterpolatedStringExpressionSyntax)
                {
                    constantValue = context.SemanticModel.GetConstantValue(node).ToString();
                }
            }
            return constantValue;
        }

        #endregion

        #region 字面量

        public static LiteralExpressionSyntax CreateStringLiteral(string text)
        {
            LiteralExpressionSyntax stringLiteral = SyntaxFactory.LiteralExpression(SyntaxKind.StringLiteralExpression, SyntaxFactory.Literal(text));
            return stringLiteral;
        }

        public static string ToLiteral(string input)
        {
            //https://stackoverflow.com/questions/55514123/convert-a-c-sharp-string-value-to-an-escaped-string-literal-with-roslyn
            return SyntaxFactory.LiteralExpression(SyntaxKind.StringLiteralExpression, SyntaxFactory.Literal(input)).ToFullString();
        }

        #endregion

        public static INamedTypeSymbol GetType(GeneratorExecutionContext context, string fullyQualifiedMetadataName)
        {
            return context.Compilation.GetTypeByMetadataName(fullyQualifiedMetadataName);
        }

        #region 获得代码片段内容

        public static string GetCodeFragment(GeneratorSyntaxContext context) =>
            GetCodeFragment(context, context.Node.Span);

        public static string GetCodeFragment(GeneratorSyntaxContext context, Microsoft.CodeAnalysis.Text.TextSpan textSpan)
        {
            var code = context.Node.SyntaxTree.ToString();
            var codeFragment = code.Substring(textSpan.Start, textSpan.End - textSpan.Start);
            return codeFragment;
        }

        public static string GetCodeFullFragment(GeneratorSyntaxContext context) =>
            GetCodeFullFragment(context, context.Node.FullSpan);

        public static string GetCodeFullFragment(GeneratorSyntaxContext context, Microsoft.CodeAnalysis.Text.TextSpan fullSpan)
        {
            var code = context.Node.SyntaxTree.ToString();
            fullSpan = context.Node.FullSpan;
            var codeFullFragment = code.Substring(fullSpan.Start, fullSpan.End - fullSpan.Start);
            return codeFullFragment;
        }

        #endregion
    }
}