﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Text;

namespace AutoPrimitive.Helpers
{
    internal class SymbolHelper
    {
        public static bool CompareSymbol(INamedTypeSymbol namedTypeSymbol, ISymbol symbol)
        {
            var isEqual = SymbolEqualityComparer.Default.Equals(namedTypeSymbol, symbol);
            return isEqual;
        }

        public static bool CompareSymbol(ISymbol namedTypeSymbol, ISymbol symbol)
        {
            var isEqual = SymbolEqualityComparer.Default.Equals(namedTypeSymbol, symbol);
            return isEqual;
        }
    }
}